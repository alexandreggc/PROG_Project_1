T07_G09

GROUP MEMBERS:
-Alexandre Correia
-Henrique Silva

PROGRAM DEVELOPMENT STATE:
-The objective of the project was globally achieved and all the goals were acomplished.
-We added our own feature in the leaderboard, sorting it in alphabetical order in case of a draw.

MAIN DIFFICULTIES:
-Our main difficulty was also related with the leaderboard creation as we were not used to 
work with files and found librarys in C++ related to this theme unintuitive.
-Text formatting in general was also a challenge.
-Overall our difficulties were due to short knowledge of the language.